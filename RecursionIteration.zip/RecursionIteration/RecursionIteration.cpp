

#include <iostream>
using namespace std;

int fact_recursive (int n) {
	if ((n == 0) || (n == 1))
		return 1;
	else
		return n * fact_recursive(n - 1);
}
int fact_iteration(int n)
{
	int res = 1, i;

	for (i = 2; i <= n; i++)
		res *= i;

	return res;
}
int main() {
	int n = 5;
	cout << "Factorial of " << n << " is " << fact_recursive(n) << endl;
	cout << "Factorial of " << n << " is " << fact_iteration(n);
	return 0;
}